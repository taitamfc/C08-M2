<?php
class ProductModel {
	public function getAll(){
		return [];
	}
	public function find($id){
		return [];
	}
	public function destroy($id){
		return [];
	}
	public function store(){
		return [];
	}
	public function update(){
		return [];
	}
}