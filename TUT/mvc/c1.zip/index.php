<?php
include_once './controller.php';
$objController = new NoteController();
$page = ( isset( $_GET['page'] ) ) ? $_GET['page'] : 'index';
switch ($page) {
	case 'index':
		$objController->index();
		break;
	case 'add':
		$objController->add();
		break;
	case 'edit':
		$objController->edit();
		break;
	default:
		// code...
		break;
}